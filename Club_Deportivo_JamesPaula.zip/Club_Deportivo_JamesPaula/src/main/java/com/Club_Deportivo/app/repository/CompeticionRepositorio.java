package com.Club_Deportivo.app.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Club_Deportivo.app.entity.Competicion;

public interface CompeticionRepositorio extends JpaRepository<Competicion, Integer>{

}
