package com.Club_Deportivo.app.view;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.view.document.AbstractPdfView;

import com.Club_Deportivo.app.entity.Entrenador;
import com.Club_Deportivo.app.repository.EntrenadorRepositorio;
import com.lowagie.text.Document;
import com.lowagie.text.Element;
import com.lowagie.text.PageSize;
import com.lowagie.text.Phrase;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;

@Component("verEntrenador")

public class ListadoPDF extends AbstractPdfView {
	
	@Autowired
	private EntrenadorRepositorio entrenadorRepositorio;

	private static final String[] header = { "Id", "Nombre", "Apellido", "Edad", "Nacionalidad" };

	@Override
	protected void buildPdfDocument(Map<String, Object> model, Document document, PdfWriter writer,
			HttpServletRequest request, HttpServletResponse response) throws Exception {

		@SuppressWarnings("unchecked")
		List<Entrenador> listaEntrenador = entrenadorRepositorio.findAll();
		List<Entrenador> listadoEntrenadores = listaEntrenador; //(List<Entrenador>) model.get("listadoEntrenadores")

		document.setPageSize(PageSize.LETTER.rotate());
		document.open();

		PdfPTable tablaTitulo = new PdfPTable(1);
		PdfPCell celda = null;
		celda = new PdfPCell(new Phrase("Listado de Entrenadores"));
		celda.setHorizontalAlignment(Element.ALIGN_CENTER);

		tablaTitulo.addCell(celda);
		tablaTitulo.setSpacingAfter(30);

		PdfPTable tablaEntrenadores = new PdfPTable(5);

		for (int i = 0; i < header.length; i++) {
			tablaEntrenadores.addCell(header[i]);
		}

		listadoEntrenadores.forEach(cliente -> {

			tablaEntrenadores.addCell(cliente.getId().toString());
			tablaEntrenadores.addCell(cliente.getNombre());
			tablaEntrenadores.addCell(cliente.getApellido());
			tablaEntrenadores.addCell(cliente.getEdad());
			tablaEntrenadores.addCell(cliente.getNacionalidad());

		});

		document.add(tablaTitulo);
		document.add(tablaEntrenadores);

	}
}
