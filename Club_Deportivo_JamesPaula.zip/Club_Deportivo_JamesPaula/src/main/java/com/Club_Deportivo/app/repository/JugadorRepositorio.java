package com.Club_Deportivo.app.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Club_Deportivo.app.entity.Jugador;

public interface JugadorRepositorio extends JpaRepository<Jugador, Integer>{

}
