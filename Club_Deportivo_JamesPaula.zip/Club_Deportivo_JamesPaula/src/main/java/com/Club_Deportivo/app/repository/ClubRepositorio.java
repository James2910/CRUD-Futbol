package com.Club_Deportivo.app.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Club_Deportivo.app.entity.Club;

public interface ClubRepositorio extends JpaRepository<Club, Integer>{

}
