package com.Club_Deportivo.app.controller;


import org.springframework.web.bind.annotation.GetMapping;




public class ControllerInicio {
	
	
	
	@GetMapping("/,/index")
	public String verPaginaInicio(){
		return "index";
	}
	
}