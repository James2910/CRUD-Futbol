package com.Club_Deportivo.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClubFutbolApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClubFutbolApplication.class, args);
	}

}
